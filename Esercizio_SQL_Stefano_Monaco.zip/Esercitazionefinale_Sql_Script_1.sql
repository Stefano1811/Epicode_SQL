CREATE SCHEMA `toys_group` ;
USE toys_group;

CREATE TABLE `toys_group`.`prodotti` (
  `idprodotto` INT NOT NULL,
  `nome_prodotto` VARCHAR(45) NOT NULL,
  `categoria` VARCHAR(45) NOT NULL,
  `prezzo_listino` DECIMAL(6,2) NOT NULL,
  PRIMARY KEY (`idprodotto`));
  
  CREATE TABLE `toys_group`.`area_geografica` (
  `idarea_geografica` INT NOT NULL,
  `regione` VARCHAR(45) NOT NULL,
  `città` VARCHAR(45) NOT NULL,
  `cap` INT NOT NULL,
  PRIMARY KEY (`idarea_geografica`));
  
  CREATE TABLE `toys_group`.`vendite` (
  `idvendita` INT NOT NULL,
  `data_vendita` DATE NOT NULL,
  `idprodotto` INT NOT NULL,
  `idarea_geografica` INT NOT NULL,
  `quantità` INT NOT NULL,
  `prezzo_listino` DECIMAL(6,2) NOT NULL,
  `totale` DECIMAL(6,2) NOT NULL,
  PRIMARY KEY (`idvendita`),
  INDEX `vendite_prodotti_idx` (`idprodotto` ASC) VISIBLE,
  INDEX `vendite_areageografica_idx` (`idarea_geografica` ASC) VISIBLE,
  CONSTRAINT `vendite_prodotti`
    FOREIGN KEY (`idprodotto`)
    REFERENCES `toys_group`.`prodotti` (`idprodotto`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `vendite_areageografica`
    FOREIGN KEY (`idarea_geografica`)
    REFERENCES `toys_group`.`area_geografica` (`idarea_geografica`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    ALTER TABLE `toys_group`.`area_geografica` 
ADD COLUMN `paese` VARCHAR(45) NOT NULL AFTER `idarea_geografica`;

ALTER TABLE `toys_group`.`area_geografica` 
DROP COLUMN `cap`;

ALTER TABLE `toys_group`.`area_geografica` 
CHANGE COLUMN `città` `città` VARCHAR(45) NOT NULL AFTER `idarea_geografica`,
CHANGE COLUMN `regione` `regione` VARCHAR(45) NOT NULL AFTER `città`,
CHANGE COLUMN `paese` `stato` VARCHAR(45) NOT NULL ;
